import unittest
from selenium import webdriver
 
import webscrapping

class pythonTest(unittest.TestCase):
    

    def test_title(self):
        print('name test')
        self.assertEqual(webscrapping.name(), ' Hotel Bristol Berlin')
    
    def test_stars(self):
        print('stars test')
        self.assertEqual(webscrapping.stars(), '5 stars')    
   
    def test_reviews(self):
        print('reviews test')
        self.assertEqual(webscrapping.reviews(), '3,390 reviews')    
 
    def test_rate(self):
        print('rate test')
        self.assertEqual(webscrapping.rate(), '8.1')    
    
    @unittest.skip(" skipping")
    def test_prices(self):
        print('prices test')
        price=webscrapping.prices()
        p=['€ 3,259.20', '€ 3,422', '€ 4,252','€ 3,837', '€ 3,641','€ 4,470', '€ 4,056', '€ 4,296', '€ 4,296', '€ 5,126', '€ 4,711', '€ 4,514', '€ 5,344', '€ 4,929', '€ 4,733', '€ 5,562', '€ 5,148', '€ 5,825', '€ 6,654','€ 6,240', '€ 34,830','€ 35,660','€ 35,321','€ 36,566','€ 35,245']
        j=0
        for i in price: 
            self.assertEqual(str(i), str(p[j]))
            j=j+1    
                                                                
if __name__ == '__main__':
    unittest.main()