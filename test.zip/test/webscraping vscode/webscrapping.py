import selenium
from selenium import webdriver
import json 

driver = webdriver.Chrome(executable_path="C:\\Users\jawhe\Desktop\webscrapping\chromedriver.exe")
driver.get("https://www.booking.com/hotel/de/kempinskibristolberlin.en-gb.html?aid=304142;label=gen173nr-1DCAsoO0IWa2VtcGluc2tpYnJpc3RvbGJlcmxpbkgJWARoO4gBAZgBCbgBBMgBBNgBA-gBAfgBC6gCA9gCAg;sid=fd63b04604b7ba5ce70f52e1e635bd76;all_sr_blocks=6066428_340785799_2_2_0;checkin=2022-03-01;checkout=2022-03-27;dest_id=62665;dest_type=hotel;dist=0;group_adults=2;group_children=0;hapos=4;highlighted_blocks=6066428_340785799_2_2_0;hpos=4;matching_block_id=6066428_340785799_2_2_0;no_rooms=1;req_adults=2;req_children=0;room1=A%2CA;sb_price_type=total;sr_order=popularity;sr_pri_blocks=6066428_340785799_2_2_0__342216;srepoch=1644148444;srpvid=09ae53ab0e40010c;type=total;ucfs=1&#hotelTmpl")

#get the name of hotel 
def name():
    hotelname = driver.find_element_by_xpath('//*[@class="hp__hotel-title"]/h2').text
    hotelname=hotelname.replace('Hotel','',1)
    return hotelname

#get the address of hotel 
def adress():
    adress= driver.find_element_by_class_name('hp_address_subtitle').text
    return adress

#get the rating of hotel 
def rate():
    rate=driver.find_element_by_class_name('_9c5f726ff').text
    return rate

#get the number of reviews of hotel 
def reviews():
    reviews=driver.find_element_by_class_name('_4abc4c3d5 ').text  
    return reviews
    
#get the prices rooms and suites in hotel 
def prices():
    prices=[]
    p=driver.find_elements_by_class_name('prco-valign-middle-helper')
    for b in p:
         w=b.text
         prices.append(w)
    return prices     

#get the number of stars of the hotel 
def stars():   
    i=0
    p=driver.find_element_by_xpath('//*[@id="wrap-hotelpage-top"]/div[2]/span/span[1]/div/div/span/div/span[1]')
    p=p.find_elements_by_tag_name('span')
    for b in p:
        i=i+1
    if i ==0:
        i=str(i)
        stars = i+" star"
    else:
        i=str(i)
        stars= i+" stars"
    return stars


#get the description of the hotel 
def description(): 
    description=[]
    p=driver.find_element_by_xpath('//*[@id="property_description_content"]')
    p=p.find_elements_by_tag_name('p')
    for b in p:
        w= b.text
    description.append(w)
    return description

#get some infomations(names, photos , prices..) of nearest hotels of the current hotel 
def others(): 
    others=[]
    a=driver.find_element_by_xpath('//*[@id="hotelTmpl"]/div[3]/div/div/div/div/div/ul')
    li =  a.find_elements_by_class_name('bui-carousel__item')
    for b in li:
        name= b.find_element_by_xpath('a/div[2]/header/h3').text
        view= b.find_element_by_xpath('a/div[2]/header/h4').text
        distance= b.find_element_by_xpath('a/div[2]/div/div[1]').text
        price= b.find_element_by_xpath('a/div[2]/div/div[2]/div[2]').text
        x= b.find_element_by_xpath('a/div[1]').find_element_by_tag_name('img')
        image=x.get_attribute("src")
        lis={
        'name': name,
        'view': view,
        'distance': distance,
        'price': price,
        'image':image
             }
        others.append(lis)
    return others

#transfert data to json   output
def tojson(): 
    dict={'name of hotel':name(),
      'adress':adress(),
     'stars':stars(),
     'rate':rate(),
     'reviews':reviews(),
      'description':description(),
      'other hotels': others(),
      'prices': prices()
      
     }
    Json = json.dumps(dict)
    return Json

print(tojson())